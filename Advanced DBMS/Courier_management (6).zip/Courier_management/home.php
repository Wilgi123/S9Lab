<?php
session_start();

// Check if user is not logged in, redirect to login page
if (!isset($_SESSION['username'])) {
    header('location:./');
}

// Retrieve session data
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courier Management System</title>
    <style>
        /* Reset CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f4f4f4;
            color: #333;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 15px 0;
            text-align: center;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        header h2 {
            margin: 0;
            font-size: 24px;
        }

        nav {
            margin-top: 10px;
            display: flex;
            justify-content: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 3px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #555;
        }

        .container {
            max-width: 1600px;
            margin: 80px auto 80px;
            /* Adjust top and bottom margins */
            padding: 10px;
            background-color: #fff;
            padding-top: 100px;
            /* Add padding to accommodate header */
        }

        h2 {
            margin-top: 0;
            font-size: 30px;
            /* Increased font size */
            margin-bottom: 15px;
        }

        p {
            margin-bottom: 15px;
            text-align: justify;
        }

        ul {
            margin-left: 20px;
            margin-bottom: 15px;
        }


        /* Image styles */
        .image {
            display: block;

            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            float: right;
            /* Align images to the right */
            margin-left: 10px;
        }

        .image.left {
            float: left;
            /* Align images to the left */
            margin-right: 10px;
        }

        /* Footer styles */
        footer {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
            width: 100%;
            position: fixed;
            bottom: 0;
        }

        footer p {
            text-align: center;
            margin: 0;
        }

        .dropdown {
            position: relative;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #333;
            min-width: 160px;
            z-index: 1;
            border-radius: 5px;
            top: 40px;
            left: 0;
        }

        .dropdown-content a {
            color: #fff;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s ease;
            text-align: left;
        }

        .dropdown-content a:hover {
            background-color: #555;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }
    </style>
</head>

<body>
    <header>
        <h2>Courier Management System</h2>
        <nav>
            <div class="dropdown">
                <a href="#">Home</a>
            </div>
            <div class="dropdown">
                <a href="#">Services</a>
                <div class="dropdown-content">
                    <a href="placeorder.php">Place Order</a>
                    <a href="order_success.php">View Order</a>
                    <a href="parcel_tracking.php">Parcel Tracking</a>
                </div>
            </div>

            <div class="dropdown">
                <a href="#">About</a>
                <div class="dropdown-content">
                    <a href="#">Company Overview</a>
                    <a href="#">Team</a>
                    <a href="#">Values</a>
                </div>
            </div>
            <div>
                <a href="logout.php">Log Out</a>

            </div>
        </nav>
    </header>

    <div class="container">
        <div id="welcome">
            <h2>Welcome to our Courier Management System</h2>
            <img align="center" src="assets\w_c.jpg" style="max-width: 70%;" alt="Courier Management System" class="image left"><br>
            <p>This system helps you manage your courier operations efficiently. Whether you're a courier company, e-commerce business, or an individual entrepreneur, our platform provides comprehensive tools and solutions to streamline every aspect of your delivery process. From order management to package tracking, our system is designed to enhance operational efficiency and customer satisfaction. With a wide range of features and customizable options, we empower you to tailor the delivery experience to your unique requirements, ensuring a seamless and hassle-free process for you and your customers.</p><br>
            <br><br>
            <!--<b>Features include:</b>
            <ul>
                <li>Efficient package tracking</li>
                <li>Route optimization</li>
                <li>Real-time updates</li>
                <li>Customer notifications</li>
                <li>Multiple delivery options</li>
                <li>Customizable delivery schedules</li>
            </ul>-->
        </div><br><br>
        <img src="assets\c_service.avif" style="max-width: 40%;" alt="Courier Management System" class="image">
        <div id="services">
            <h2>Our Services</h2>
            <p>Discover the range of services we offer to meet your courier management needs. We strive to provide top-notch services tailored to your requirements. </p>
            <b>Our services include:</b>
            <ul>
                <li>Express delivery</li>
                <li>Parcel tracking</li>
                <li>International shipping</li>
                <li>Customized solutions</li>
                <li>Secure packaging</li>
            </ul>
        </div><br><br>
        <img src="assets\co_service.avif" style="max-width: 40%;" alt="Courier Management System" class="image left">
        <div id="about">
            <h2>About Us</h2>
            <p>Learn about our company and our commitment to providing reliable courier services. We are dedicated to delivering excellence and building long-lasting relationships with our clients. Our values include transparency, accountability, and continuous improvement. With a team of experienced professionals and a customer-centric approach, we strive to exceed expectations.</p>
            <!---<br><br><br><br><b>Our values include:</b>

            <ul>
                <li>Integrity</li>
                <li>Reliability</li>
                <li>Customer satisfaction</li>
                <li>Innovation</li>
            </ul>-->
        </div><br><br>
        <img src="assets\c_about.jpg" style="max-width: 30%;" alt="Courier Management System" class="image"><br><br>
        <div id="contact"><br><br>
            <h2>Contact Us</h2>
            <p>Get in touch with us for inquiries, support, or partnership opportunities. Our team is ready to assist you and provide solutions to your courier management needs. Contact us via:</p>
            <p>Email: info@couriermanagement.com</p>
            <p>Phone: 123-456-7890</p>
            <br>
            <br>
        </div>
    </div>
    <footer>
        <p>&copy; 2024 Courier Management System. All rights reserved.</p>
    </footer>
</body>

</html>