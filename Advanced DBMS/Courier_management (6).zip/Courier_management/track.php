<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Courier - Courier Management System</title>
   <!--- <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="track.css">-->
</head>
<style>
    /* Resetting default styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body, html {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    font-size: 16px;
    background: #f4f4f4;
    color: #333;
}

header {
    background: #005a87;
    color: #fff;
    padding-top: 30px;
    min-height: 70px;
    border-bottom: #0779e4 3px solid;
}

header a {
    color: #fff;
    text-decoration: none;
    text-transform: uppercase;
    margin: 0 15px;
}

header li {
    display: inline;
    padding: 0 10px;
}

.logo {
    float: left;
    margin: 0;
}

.logo h1 {
    margin: 0;
    padding: 0;
    font-size: 24px;
}

.navigation {
    float: right;
    margin-right: 30px;
}

.navigation ul {
    list-style: none;
    margin: 0;
    padding: 0;
}

.navigation ul li {
    display: inline;
    margin-left: 10px;
}

.btn {
    display: inline-block;
    background: #0779e4;
    color: #fff;
    padding: 10px 20px;
    border: none;
    cursor: pointer;
    margin-top: 10px;
}

.btn:hover {
    background: #0056b3;
}

footer {
    background: #333;
    color: #fff;
    text-align: center;
    padding: 20px;
    margin-top: 20px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
}

.form-group input[type="text"],
.form-group input[type="password"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
}

.hero {
    background: #e9ecef;
    padding: 20px;
    margin: 20px 0;
}

.hero h2 {
    margin-bottom: 20px;
}

.hero-content {
    text-align: center;
}

.active {
    background: #e9ecef;
    color: #333;
}

.track-section {
    background: #fff;
    padding: 20px;
    margin: 20px auto;
    width: 80%;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.track-container {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
}

.track-container h2 {
    text-align: center;
    color: #333;
    margin-bottom: 30px;
}

.form-group input[type="text"] {
    border-radius: 5px;
}

.btn {
    width: 100%;
    font-size: 18px;
    border-radius: 5px;
}

/* Enhancing the button hover effect from the global style */
.btn:hover {
    background: #004a75;
    color: #fff;
}

@media (max-width: 768px) {
    .track-section {
        width: 95%;
        padding: 10px;
    }

    .track-container {
        padding: 10px;
    }
}

</style>
<body>
    <header>
        <nav>
            <div class="logo">
                <h1>Courier Management System</h1>
            </div>
            <div class="navigation">
                <ul>
                    <li><a href="adminindex.php">Home</a></li>
                    <li><a href="track.php" class="active">Track</a></li>
                    <li><a href="dashboard.php" >Dashboard</a></li>
                    <li><a href="logout.php">Log Out</a></li>
                    
                </ul>
            </div>
        </nav>
    </header>
    <main>
        <section class="track-section">
            <div class="track-container">
                <h2>Track Your Courier</h2>
                <form action="track.php" method="POST">
                    <div class="form-group">
                        <label for="trackingNumber">Tracking Number:</label>
                        <input type="text" id="trackingNumber" name="trackingNumber" required>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn">Track</button>
                    </div>
                </form>
            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2023 Courier Management System</p>
    </footer>
    <script src="script.js"></script>
</body>
</html>
