<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('location:./');
}
require_once "./vendor/autoload.php";

// Connect to MongoDB
$mongoClient = new MongoDB\Client("mongodb://localhost:27017");

// Select database
$database = $mongoClient->wilgipro;

// Select collections
$collectionReg = $database->tbl_reg;
$collectionOrder = $database->tbl_order;

// Fetch data for Total Couriers
$totalCouriers = $collectionReg->countDocuments();

// Fetch data for Pending Deliveries
$pendingDeliveries = $collectionOrder->countDocuments(['status' => 'Pending']);

// Fetch data for Delivered
$delivered = $collectionOrder->countDocuments(['status' => 'Delivered']);

// Fetch data for Total Orders placed
$totalOrdersPlaced = $collectionOrder->countDocuments();

// Fetch data for Pending Orders
$pendingOrders = $collectionOrder->countDocuments(['orderstatus' => 'Pending']);

// Fetch data for Received Orders
$receivedOrders = $collectionOrder->countDocuments(['orderstatus' => 'Received']);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Courier Management System</title>
</head>
<style>
    /* Resetting default styles */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body,
    html {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        font-size: 16px;
        background: #f4f4f4;
        color: #333;
        height: 100%;
    }

    header {
        background: #005a87;
        color: #fff;
        padding-top: 30px;
        min-height: 70px;
        border-bottom: #0779e4 3px solid;
        position: sticky;
        top: 0;
        z-index: 999;
    }

    header a {
        color: #fff;
        text-decoration: none;
        text-transform: uppercase;
        margin: 0 15px;
    }

    header li {
        display: inline;
        padding: 0 10px;
    }

    .logo {
        float: left;
        margin: 0;
    }

    .logo h1 {
        margin: 0;
        padding: 0;
        font-size: 24px;
    }

    .navigation {
        float: right;
        margin-right: 30px;
    }

    .navigation ul {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    .navigation ul li {
        display: inline;
        margin-left: 10px;
    }

    .btn {
        display: inline-block;
        background: #0779e4;
        color: #fff;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
        margin-top: 10px;
    }

    .btn:hover {
        background: #0056b3;
    }

    footer {
        background: #005a87;
        color: #fff;
        text-align: center;
        padding: 20px;
        margin-top: auto;
        width: 100%;
        position: fixed;
        bottom: 0;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
    }

    .form-group input[type="text"],
    .form-group input[type="password"] {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
    }

    .hero {
        background: #e9ecef;
        padding: 20px;
        margin: 20px 0;
    }

    .hero h2 {
        margin-bottom: 20px;
    }

    .hero-content {
        text-align: center;
    }

    .active {
        background: #e9ecef;
        color: #333;
    }

    /* Dashboard specific styles */
    .dashboard-section {
        padding: 20px;
        background: #fff;
        margin: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .dashboard-container h2 {
        color: #005a87;
        margin-bottom: 20px;
    }

    .dashboard-content {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
    }

    .dashboard-box {
        background: #e9ecef;
        padding: 20px;
        border-radius: 8px;
        width: 30%;
        text-align: center;
    }

    .dashboard-box h3 {
        margin-bottom: 15px;
        color: #333;
    }

    .dashboard-box p {
        font-size: 20px;
        font-weight: bold;
        color: #005a87;
    }

    .dashboard-actions {
        text-align: center;
    }

    .dashboard-actions .btn {
        width: auto;
        padding: 10px 30px;
        font-size: 16px;
    }

    @media (max-width: 768px) {
        .dashboard-content {
            flex-direction: column;
        }

        .dashboard-box {
            width: 100%;
            margin-bottom: 20px;
        }

        .dashboard-actions {
            flex-direction: column;
        }

        .dashboard-actions .btn {
            margin-bottom: 10px;
        }
    }
</style>

<body>
    <header>
        <nav>
            <div class="logo">
                <h1>Courier Management System</h1>
            </div>
            <div class="navigation">
                <ul>
                    <li><a href="adminindex.php">Home</a></li>
                    <li><a href="#">Track</a></li>
                    <li><a href="dashboard.php" class="active">Dashboard</a></li>
                    <li><a href="logout.php">Log Out</a></li>
                </ul>
            </div>
        </nav>
    </header><br><br>
    <main>
        <section class="dashboard-section">
            <div class="dashboard-container">
                <h2>Dashboard</h2>
                <div class="dashboard-content">
                    <div class="dashboard-box">
                        <h3>Total Couriers</h3>
                        <p><?php echo $totalCouriers; ?></p>
                    </div>&nbsp; &nbsp; &nbsp;
                    <div class="dashboard-box">
                        <h3>Pending Orders</h3>
                        <p><?php echo $pendingOrders; ?></p>
                    </div>&nbsp; &nbsp; &nbsp;
                    <div class="dashboard-box">
                        <h3>Delivered Orders</h3>
                        <p><?php echo $receivedOrders; ?></p>
                    </div>&nbsp; &nbsp; &nbsp;
                    <div class="dashboard-box">
                        <h3>Total Orders Placed</h3>
                        <p><?php echo $totalOrdersPlaced; ?></p>
                    </div>
                </div>
                <div class="dashboard-actions">
                   <!--- <a href="#" class="btn">Track Courier</a>-->
                    <a href="admin.php" class="btn">Manage Couriers</a>
                </div>
            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2023 Courier Management System</p>
    </footer>
    <script src="script.js"></script>
    <script>
        // Example JavaScript to dynamically load dashboard data
        document.addEventListener('DOMContentLoaded', function() {
            // Placeholder for actual data loading logic
            document.getElementById('totalCouriers').textContent = '120';
            document.getElementById('pendingDeliveries').textContent = '45';
            document.getElementById('delivered').textContent = '75';
        });
    </script>
</body>

</html>