<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>
</head>
<style>
    * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f4f4f4;
            color: #333;
            margin-bottom: 60px;
            /* Adjust for the fixed footer height */
        }

        /* Header styles */
        header {
            background-color: #333;
            color: #fff;
            padding: 15px 0;
            text-align: center;
            position: fixed; /* Fix header position */
            width: 100%; /* Full width */
            top: 0; /* Stick to the top */
            z-index: 1000; /* Ensure header is above other content */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Add shadow for depth */
        }
       header h1 {
            margin: 0;
            font-size: 24px; /* Reduce font size */
        }

        nav {
            margin-top: 10px; /* Adjust margin for nav links */
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 5px 10px; /* Reduce padding for cleaner look */
            margin: 0 5px; /* Adjust spacing between links */
            border-radius: 3px; /* Add border radius for rounded corners */
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #555; /* Darken background color on hover */
        }

    </style>
<body>
    <!-- header.php -->
<header>
    <h2>Courier Management System</h2>
    <nav>
        <a href="#welcome">Home</a>
        <a href="#services">Services</a>
        <a href="#about">About</a>
        <a href="#contact">Contact</a>
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
    </nav>
</header>

</body>
</html>