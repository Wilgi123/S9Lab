<?php
session_start();

require_once "./vendor/autoload.php";

try {
    // MongoDB connection
    $mongoClient = new MongoDB\Client("mongodb://localhost:27017");

    // Select database
    $database = $mongoClient->wilgipro;

    // Select collection
    $collectionUsers = $database->tbl_reg;

    // Retrieve all users
    $users = $collectionUsers->find();
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Admin</title>
    <!-- Add any necessary stylesheets or libraries here -->
    <style>
        /* Resetting default styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body,
        html {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            font-size: 16px;
            background: #f4f4f4;
            color: #333;
            height: 100%;
        }

        /* Header styles */
        header {
            background: #005a87;
            color: #fff;
            padding-top: 20px;
            min-height: 70px;
            border-bottom: #0779e4 3px solid;
        }

        header a {
            color: #fff;
            text-decoration: none;
            text-transform: uppercase;
            margin: 0 15px;
        }

        .logo {
            float: left;
            margin: 0;
        }

        .logo h1 {
            margin: 0;
            padding: 0;
            font-size: 28px;
        }

        .navigation {
            float: right;
            margin-right: 30px;
        }

        .navigation ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .navigation ul li {
            display: inline;
            margin-left: 20px;
        }

        /* Footer styles */
        footer {
            background: #005a87;
            color: #fff;
            text-align: center;
            padding: 20px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        /* Courier information styles */
        .courier-container {
            width: 80%;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
            /* Allow horizontal scrolling on small screens */
        }

        .courier-container h2 {
            text-align: center;
            color: #005a87;
            margin-bottom: 20px;
        }

        /* Table styles */
        table {
            width: 50%; /* Set the table width to 80% of its container */
            border-collapse: collapse;
            margin: 0 auto; /* Center the table horizontally */
            margin-top: 20px;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #005a87;
            color: #fff;
            font-weight: bold;
            text-align: left;
            text-transform: uppercase;
        }

        /* Alternating row colors */
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        /* Hover effects */
        tr:hover {
            background-color: #e2e2e2;
        }

        /* Button container styles */
        .action-btn-container {
            display: flex;
            align-items: center;
        }

        .action-btn {
            padding: 8px 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s;
            text-transform: uppercase;
            font-weight: bold;
            letter-spacing: 1px;
            margin: 5px;
            outline: none;
        }

        /* Activate button */
        .activate-btn {
            background-color: #4CAF50;
            color: white;
        }

        /* Deactivate button */
        .deactivate-btn {
            background-color: #f44336;
            color: white;
        }

        /* Hover effects */
        .action-btn:hover {
            opacity: 0.8;
        }

        /* Active state */
        .action-btn:active {
            transform: translateY(1px);
        }

        /* Disabled state */
        .action-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Responsive design */
        @media screen and (max-width: 768px) {
            .courier-container {
                width: 100%;
                overflow-x: auto;
            }
        }
    </style>
</head>

<body>
    <header>
        <div class="logo">
            <h1>Courier Management System</h1>
        </div>
        <div class="navigation">
            <ul>
                <li><a href="adminindex.php">Home</a></li>
                <li><a href="track.php">Track</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </div>
    </header>

    <main>
        <br><br>
        <div class="user-container">
            <h2 align="center">Manage Users</h2>
            <table>
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($users as $user) : ?>
    <tr>
        <td><?php echo isset($user['username']) ? $user['username'] : ''; ?></td>
        <td><?php echo isset($user['email']) ? $user['email'] : ''; ?></td>
        <td><?php echo isset($user['status']) ? $user['status'] : ''; ?></td>
        <td>
            <?php if (isset($user['status']) && $user['status'] === 'Active') : ?>
                <button type="button" class="action-btn deactivate-btn" data-user-id="<?php echo $user['_id']; ?>" data-status="Active" onclick="toggleUserStatus('<?php echo $user['_id']; ?>', 'Deactivate', 'deactivate')">Deactivate</button>
            <?php else : ?>
                <button type="button" class="action-btn activate-btn" data-user-id="<?php echo $user['_id']; ?>" data-status="Inactive" onclick="toggleUserStatus('<?php echo $user['_id']; ?>', 'Activate', 'activate')">Activate</button>
            <?php endif; ?>
        </td>
    </tr>
<?php endforeach; ?>

                </tbody>
            </table>
        </div>
        <br><br>
    </main><br><br>

    <footer>
        <p>&copy; 2023 Courier Management System</p>
    </footer>
    <script>
    function toggleUserStatus(userId, buttonText, action) {
        const button = document.querySelector(`button[data-user-id="${userId}"]`);
        button.innerText = buttonText === 'Activate' ? 'Activating...' : 'Deactivating...';
        button.disabled = true;

        if (action === 'deactivate') {
            // Show confirmation dialog
            if (!confirm('Are you sure you want to deactivate this user?')) {
                button.innerText = buttonText;
                button.disabled = false;
                return;
            }
        }

        fetch('toggle_user_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'userId=' + userId + '&action=' + action,
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    const newButtonText = action === 'activate' ? 'Deactivate' : 'Activate';
                    const newStatus = data.newStatus;
                    button.innerText = newButtonText;
                    button.disabled = false;
                    button.setAttribute('onclick', `toggleUserStatus('${userId}', '${newButtonText}', '${action === 'activate' ? 'deactivate' : 'activate'}')`);
                    // Toggle button class dynamically
                    button.classList.remove(action === 'activate' ? 'activate-btn' : 'deactivate-btn');
                    button.classList.add(action === 'activate' ? 'deactivate-btn' : 'activate-btn');
                    const statusCell = button.parentNode.previousElementSibling;
                    statusCell.textContent = newStatus;
                } else {
                    button.innerText = buttonText;
                    button.disabled = false;
                    console.error('Error toggling user status:', data.message);
                }
            })
            .catch(error => {
                button.innerText = buttonText;
                button.disabled = false;
                console.error('Error toggling user status:', error);
            });
    }
</script>




</body>

</html>