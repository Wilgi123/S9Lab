<?php
session_start();

// Check if admin is not logged in, redirect to login page
if (!isset($_SESSION['admin'])) {
    header('location:./');
}

// Retrieve admin's username
$username = $_SESSION['admin'];

require_once "./vendor/autoload.php";

// MongoDB connection
$mongoClient = new MongoDB\Client("mongodb://localhost:27017");

// Select database
$database = $mongoClient->wilgipro;

// Select collections
$ordersCollection = $database->tbl_order;
$couriersCollection = $database->tbl_courier;
$customersCollection = $database->tbl_customer;

// Retrieve total orders count
$totalOrdersCount = $ordersCollection->countDocuments();

// Retrieve pending orders count
$pendingOrdersCount = $ordersCollection->countDocuments(['status' => 'pending']);

// Retrieve delivered orders count
$deliveredOrdersCount = $ordersCollection->countDocuments(['status' => 'delivered']);

// You can add more metrics as needed

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courier Management System</title>
    <!---<link rel="stylesheet" href="style.css">--->
</head>
<style>
/* Resetting default styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body, html {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    font-size: 16px;
    background: #f4f4f4;
    color: #333;
    height: 100%; /* Set the body and html height to 100% */
}

header {
    background: #005a87;
    color: #fff;
    padding-top: 20px;
    min-height: 70px;
    border-bottom: #0779e4 3px solid;
    position: sticky;
    top: 0;
    z-index: 999;
}

header a {
    color: #fff;
    text-decoration: none;
    text-transform: uppercase;
    margin: 0 15px;
}

.logo {
    float: left;
    margin: 0;
}

.logo h1 {
    margin: 0;
    padding: 0;
    font-size: 28px; /* Increased font size */
}

.navigation {
    float: right;
    margin-right: 30px;
}

.navigation ul {
    list-style: none;
    margin: 0;
    padding: 0;
}

.navigation ul li {
    display: inline;
    margin-left: 20px; /* Increased margin */
}

.btn {
    display: inline-block;
    background: #0779e4;
    color: #fff;
    padding: 12px 24px; /* Increased padding */
    border: none;
    cursor: pointer;
    margin-top: 20px;
    border-radius: 5px; /* Added border radius */
}

.btn:hover {
    background: #0056b3;
}

footer {
    background: #005a87; /* Changed background color */
    color: #fff;
    text-align: center;
    padding: 20px;
    position: fixed; /* Set the footer position to fixed */
    bottom: 0; /* Align the footer to the bottom */
    width: 100%; /* Set the width to 100% */
}

.hero {
    background: #e9ecef;
    padding: 80px 20px; /* Increased padding */
    margin: 40px 0; /* Increased margin */
    text-align: center;
}

.hero h2 {
    margin-bottom: 20px;
    font-size: 36px; /* Increased font size */
}

.hero p {
    font-size: 18px; /* Increased font size */
}

.active {
    background: #e9ecef;
    color: #333;
}



</style>
<body>
    <header>
        <nav>
            <div class="logo">
                <h1>Courier Management System</h1>
            </div>
            <div class="navigation">
                <ul>
                    <li><a href="adminindex.php">Home</a></li>
                    <li><a href="track.php">Track</a></li>
                    <li><a href="dashboard.php" >Dashboard</a></li>
                    <li><a href="logout.php">Log Out</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <main>
        <section class="hero">
            <div class="hero-content">
                <h2>Welcome to Courier Management System</h2>
                <p>Efficiently manage and track your courier deliveries.</p>
                <a href="dashboard.php" class="btn">Get Started</a>
            </div>
        </section>
        <section>
            <div style="text-align: center; padding: 20px;">
                <h3>About Us</h3>
                <p>We are a leading courier management system provider, dedicated to helping businesses streamline their delivery processes.</p>
            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2023 Courier Management System</p>
    </footer>
    <script src="script.js"></script>
</body>
</html>
