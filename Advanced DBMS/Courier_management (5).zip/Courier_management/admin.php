
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Courier Management System</title>
</head>
<style>
/* Resetting default styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body, html {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    font-size: 16px;
    background: #f4f4f4;
    color: #333;
    height: 100%;
}

header {
    background: #005a87;
    color: #fff;
    padding-top: 20px;
    min-height: 70px;
    border-bottom: #0779e4 3px solid;
}

header a {
    color: #fff;
    text-decoration: none;
    text-transform: uppercase;
    margin: 0 15px;
}

.logo {
    float: left;
    margin: 0;
}

.logo h1 {
    margin: 0;
    padding: 0;
    font-size: 28px;
}

.navigation {
    float: right;
    margin-right: 30px;
}

.navigation ul {
    list-style: none;
    margin: 0;
    padding: 0;
}

.navigation ul li {
    display: inline;
    margin-left: 20px;
}

.btn {
    display: inline-block;
    background: #0779e4;
    color: #fff;
    padding: 12px 24px;
    border: none;
    cursor: pointer;
    margin-top: 20px;
    border-radius: 5px;
    text-decoration: none;
}

.btn:hover {
    background: #0056b3;
}

footer {
    background: #005a87;
    color: #fff;
    text-align: center;
    padding: 20px;
    position: fixed;
    bottom: 0;
    width: 100%;
}

.admin-section {
    display: flex;
    justify-content: center;
    align-items: center;
    height: calc(100% - 160px);
}

.admin-container {
    width: 80%;
    background: #fff;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.admin-container h2 {
    margin-bottom: 20px;
    text-align: center;
}

.admin-content {
    display: flex;
    justify-content: space-around;
}

.admin-box {
    flex: 1;
    margin: 0 10px;
    text-align: center;
    padding: 20px;
    background: #f9f9f9;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
}

.admin-box h3 {
    margin-bottom: 10px;
}

.admin-box p {
    margin-bottom: 20px;
}
</style>
<body>
    <header>
        <div class="logo">
            <h1>Courier Management System</h1>
        </div>
        <div class="navigation">
            <ul>
                <li><a href="adminindex.php">Home</a></li>
                <li><a href="track.php">Track</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </div>
    </header>
    <main><br><br><br>
        <section class="admin-section"><br><br><br><br>
            <div class="admin-container"><br><br>
                <h2>Admin Dashboard</h2><br>
                <div class="admin-content">
                    <div class="admin-box">
                        <h3>Manage Couriers</h3>
                        <p>View and delete courier records.</p>
                        <a href="viewcourier.php" class="btn">Manage</a>
                    </div>
                    <div class="admin-box">
                        <h3>Manage Users</h3>
                        <p>View and delete user accounts.</p>
                        <a href="manage_users.php" class="btn">Manage</a>
                    </div>
                   <!-- <div class="admin-box">
                        <h3>Reports</h3>
                        <p>View reports on courier deliveries, user activities, and more.</p>
                        <a href="#" class="btn">View Reports</a>
                    </div>-->
                </div>
            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2023 Courier Management System</p>
    </footer>
</body>
</html>
