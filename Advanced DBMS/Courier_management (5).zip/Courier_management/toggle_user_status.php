<?php
session_start();

require_once "./vendor/autoload.php";

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // MongoDB connection
        $mongoClient = new MongoDB\Client("mongodb://localhost:27017");

        // Select database
        $database = $mongoClient->wilgipro;

        // Select collection
        $collectionUsers = $database->tbl_reg;

        // Get user ID and action from POST data
        $userId = $_POST['userId'];
        $action = $_POST['action'];

        // Update user status based on action
        $newStatus = ($action === 'activate') ? 'Active' : 'Inactive';
        $collectionUsers->updateOne(
            ['_id' => new MongoDB\BSON\ObjectID($userId)],
            ['$set' => ['status' => $newStatus]]
        );

        // Return JSON response with success and new status
        echo json_encode(['success' => true, 'newStatus' => $newStatus]);
    } catch (Exception $e) {
        // Return JSON response with error message
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    // Return JSON response with error message for invalid request method
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
