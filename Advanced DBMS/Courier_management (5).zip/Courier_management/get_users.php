<?php
session_start();

require_once "./vendor/autoload.php";

try {
    // MongoDB connection
    $mongoClient = new MongoDB\Client("mongodb://localhost:27017");

    // Select database
    $database = $mongoClient->wilgipro;

    // Select collection
    $collectionUsers = $database->tbl_reg;

    // Retrieve all users
    $users = $collectionUsers->find();

    // Convert users to array and return as JSON
    $usersArray = iterator_to_array($users);
    echo json_encode($usersArray);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
