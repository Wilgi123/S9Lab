<?php
session_start();

require_once "./vendor/autoload.php";

try {
    // MongoDB connection
    $mongoClient = new MongoDB\Client("mongodb://localhost:27017");

    // Select database
    $database = $mongoClient->wilgipro;

    // Select collection
    $collectionOrder = $database->tbl_order;

    // Retrieve all orders
    $orders = $collectionOrder->find();
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Couriers - Admin</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.css">
    <style>
        /* Resetting default styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body,
        html {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            font-size: 16px;
            background: #f4f4f4;
            color: #333;
            height: 100%;
        }

        /* Header styles */
        header {
            background: #005a87;
            color: #fff;
            padding-top: 20px;
            min-height: 70px;
            border-bottom: #0779e4 3px solid;
        }

        header a {
            color: #fff;
            text-decoration: none;
            text-transform: uppercase;
            margin: 0 15px;
        }

        .logo {
            float: left;
            margin: 0;
        }

        .logo h1 {
            margin: 0;
            padding: 0;
            font-size: 28px;
        }

        .navigation {
            float: right;
            margin-right: 30px;
        }

        .navigation ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .navigation ul li {
            display: inline;
            margin-left: 20px;
        }

        /* Footer styles */
        footer {
            background: #005a87;
            color: #fff;
            text-align: center;
            padding: 20px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        /* Courier information styles */
        .courier-container {
            width: 80%;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow-x: auto; /* Allow horizontal scrolling on small screens */
        }

        .courier-container h2 {
            text-align: center;
            color: #005a87;
            margin-bottom: 20px;
        }

        /* Table styles */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        /* Alternating row colors */
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        /* Hover effects */
        tr:hover {
            background-color: #f2f2f2;
        }

        /* Button container styles */
        .action-btn-container {
            display: flex;
            align-items: center;
        }

        /* Button styles */
        .action-btn {
            padding: 8px 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .dispatch-btn {
            background-color: #4CAF50;
            color: white;
        }

        .delete-btn {
            background-color: #f44336;
            color: white;
        }

        .action-btn:hover {
            opacity: 0.8;
        }

        .action-btn:active {
            transform: translateY(1px);
        }

        .hide {
            display: none;
        }

        /* Responsive design */
        @media screen and (max-width: 768px) {
            .courier-container {
                width: 100%;
                overflow-x: auto;
            }
        }
    </style>
</head>

<body>
    <header>
        <div class="logo">
            <h1>Courier Management System</h1>
        </div>
        <div class="navigation">
            <ul>
                <li><a href="adminindex.php">Home</a></li>
                <li><a href="track.php">Track</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </div>
    </header>

    <main>
        <div class="courier-container">
            <h2>View Couriers</h2>
            <table >
                <thead>
                    <tr>
                        <th>Username</th> <!-- Adding Username column -->
                        <th>Tracking Number</th>
                        <th>Pickup Location</th>
                        <th>Delivery Address</th>
                        <th>Package Size</th>
                        <th>Package Weight</th>
                        <th>Delivery Speed</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order) : ?>
                        <tr>
                            <td><?php echo isset($order['username']) ? $order['username'] : 'Unknown'; ?></td> <!-- Displaying username -->
                            <td><?php echo isset($order['tracking_number']) ? $order['tracking_number'] : 'Unknown'; ?></td>
                            <td><?php echo $order['pickup_location']; ?></td>
                            <td><?php echo $order['delivery_address']; ?></td>
                            <td><?php echo $order['package_size']; ?></td>
                            <td><?php echo $order['package_weight']; ?></td>
                            <td><?php echo $order['delivery_speed']; ?></td>
                            <td><?php echo $order['orderstatus']; ?></td> <!-- Display order status -->
                            <td>
                                <?php if ($order['orderstatus'] !== 'Received') : ?>
                                    <div class="action-btn-container">
                                        <?php if ($order['orderstatus'] !== 'Dispatched') : ?> <!-- Display dispatch button only if order status is not Dispatched -->
                                            <button type="button" class="action-btn dispatch-btn" data-order-id="<?php echo $order['_id']; ?>" onclick="dispatchOrder('<?php echo $order['_id']; ?>')">Dispatch</button>&nbsp;&nbsp;
                                        <?php endif; ?>
                                        <form action="delete_order_admin.php" method="post"> <!-- Form for deleting order -->
                                            <input type="hidden" name="orderId" value="<?php echo $order['_id']; ?>">
                                            <button type="submit" class="action-btn delete-btn">Delete</button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main><br><br>
    <footer>
        <p>&copy; 2023 Courier Management System</p>
    </footer>
    <script>
        function dispatchOrder(orderId) {
            // Update the button text to "Dispatching..."
            const dispatchBtn = document.querySelector(`button[data-order-id="${orderId}"]`);
            dispatchBtn.innerText = 'Dispatching...';

            // Send an AJAX request to update the order status
            fetch('update_order_status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'orderId=' + orderId,
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    // If the request is successful, update the button text to "Dispatched", hide the button, and update the status in the table
                    if (data.success) {
                        dispatchBtn.innerText = 'Dispatched';
                        dispatchBtn.style.display = 'none'; // Hide the dispatch button
                        const statusCell = dispatchBtn.closest('tr').querySelector('td:nth-child(8)'); // Target the status cell
                        statusCell.textContent = 'Dispatched'; // Update status in the table
                    } else {
                        // If there's an error, display the error message and revert the button text to "Dispatch"
                        console.error('Error dispatching order:', data.message);
                        dispatchBtn.innerText = 'Dispatch';
                    }
                })
                .catch(error => {
                    // If the request fails, display an error message and revert the button text to "Dispatch"
                    console.error('Error dispatching order:', error);
                    dispatchBtn.innerText = 'Dispatch';
                });
        }
    </script>
<script>new DataTable('#example');</script>

</body>

</html>
