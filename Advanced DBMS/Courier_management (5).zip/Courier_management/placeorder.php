<?php
session_start();

// Check if user is not logged in, redirect to login page
if (!isset($_SESSION['username'])) {
    header('location:./');
}

require_once "./vendor/autoload.php";

// Retrieve session data
$username = $_SESSION['username'];

// Generate a random tracking number
$tracking_number = uniqid();

// MongoDB connection
$mongoClient = new MongoDB\Client("mongodb://localhost:27017");

// Select database
$database = $mongoClient->wilgipro;

// Select collection
$collection = $database->tbl_order;

// Handle form submission
if (isset($_POST['submit'])) {
    // Retrieve form data
    $pickup_location = htmlspecialchars($_POST["pickup_location"]);
    $delivery_address = htmlspecialchars($_POST["delivery_address"]);
    $package_size = htmlspecialchars($_POST["package_size"]);
    $package_weight = htmlspecialchars($_POST["package_weight"]);
    $delivery_speed = htmlspecialchars($_POST["delivery_speed"]);

    // Basic form validation
    if (empty($pickup_location) || empty($delivery_address) || empty($package_size) || empty($package_weight) || empty($delivery_speed)) {
        // Redirect with error message if any field is empty
        header("Location: placeorder.php?error=1");
        exit;
    }

    // Create document to insert into collection with default order status
    $document = [
        "tracking_number" => $tracking_number,
        "pickup_location" => $pickup_location,
        "delivery_address" => $delivery_address,
        "package_size" => $package_size,
        "package_weight" => $package_weight,
        "delivery_speed" => $delivery_speed,
        "username" => $username, // Assuming you want to associate the order with the current user
        "orderstatus" => "Pending" // Default order status
    ];

    // Insert document into collection
    $insertOneResult = $collection->insertOne($document);

    // Check if insertion was successful
    if ($insertOneResult->getInsertedCount() === 1) {
        // Order placed successfully
        // Redirect to order success page with tracking number
        header("Location: order_success.php?tracking_number=$tracking_number");
        exit;
    } else {
        // Failed to insert document
        // Redirect or show error message
        header("Location: placeorder.php?error=2");
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Place Order - Courier Management System</title>
    <style>
        /* Reset CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f4f4f4;
            color: #333;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 15px 20px;
            /* Adjusted padding for better spacing */
            display: flex;
            /* Use flexbox for layout */
            justify-content: space-between;
            /* Align items with space between */
            align-items: center;
            /* Vertically center items */
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        header h2 {
            margin: 0;
            font-size: 24px;
        }

        nav {
            display: flex;
            /* Use flexbox for layout */
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 3px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #555;
        }


        .container {
            max-width: 800px;
            /* Adjusted width for better readability */
            margin: 100px auto;
            /* Adjusted margin for better alignment */
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 28px;
            margin-bottom: 20px;
            text-align: center;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 12px 20px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
            width: 100%;
            /* Set button width to 100% */
            box-sizing: border-box;
            /* Ensure padding and border are included in width calculation */
        }

        input[type="submit"]:hover {
            background-color: #555;
        }


        footer {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
            width: 100%;
            position: fixed;
            bottom: 0;
        }

        footer p {
            text-align: center;
            margin: 0;
        }
    </style>
</head>

<body>
    <header>
        <h2>Courier Management System</h2>
        <nav>
            <a href="home.php">Home</a>
            <a href="placeorder.php">Place Order</a>
            <a href="order_success.php">View Order</a>
            <a href="parcel_tracking.php">Parcel Tracking</a>
            <a href="logout.php">Log Out</a>
        </nav>
    </header>

    <div class="container">
        <h1>Place Order</h1>
        <!-- Your order form goes here -->
        <form action="#" method="post">
            <label for="pickup_location">Pickup Location:</label>
            <input type="text" id="pickup_location" name="pickup_location" required>

            <label for="delivery_address">Delivery Address:</label>
            <input type="text" id="delivery_address" name="delivery_address" required>

            <label for="package_size">Package Size:</label>
            <select id="package_size" name="package_size">
                <option value="small">Small</option>
                <option value="medium">Medium</option>
                <option value="large">Large</option>
            </select>

            <label for="package_weight">Package Weight:</label>
            <input type="text" id="package_weight" name="package_weight" required>

            <label for="delivery_speed">Delivery Speed:</label>
            <select id="delivery_speed" name="delivery_speed">
                <option value="standard">Standard</option>
                <option value="express">Express</option>
            </select>

            <input type="submit" name="submit" value="Place Order">
        </form>
    </div>

    <footer>
        <p>&copy; 2024 Courier Management System. All rights reserved.</p>
    </footer>
</body>

</html>
