<?php
if (isset($_POST['submit'])) {
    require "./vendor/autoload.php";
    $con = new MongoDB\Client("mongodb://localhost:27017");
    $db = $con->wilgipro;
    $collection = $db->tbl_reg; 

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Hash the password before storing it
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $document = [
        'username' => $username,
        'email' => $email,
        'password' => $hashedPassword // Store hashed password
    ];

    $result = $collection->insertOne($document);

    if ($result->getInsertedCount() > 0) {
        echo "<script>alert('Data inserted successfully.');</script>";
        header("Location: login.php"); // Redirect to login page after successful registration
    } else {
        echo "<script>alert('Failed to insert data.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>
    <style>
       body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        .container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: calc(100% - 22px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .form-group input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 0;
            width: 100%;
            border-radius: 3px;
            cursor: pointer;
            font-size: 16px;
        }
        .form-group input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .signin-link {
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<?php include 'header.php'; ?> <!-- Include header -->
    <div class="container">
        <h2>Registration Form</h2>
        <form action="#" method="POST">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="text" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <input type="submit" value="Submit" name="submit">
            </div>
            <div class="signin-link">
            <p>Already have an account? <a href="login.php">Sign in</a></p>
        </div>
        </form>
    </div>
    <?php include 'footer.php'; ?> <!-- Include footer -->
</body>
</html>
