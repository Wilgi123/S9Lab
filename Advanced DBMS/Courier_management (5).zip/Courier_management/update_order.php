<?php
session_start();

// Check if user is not logged in, redirect to login page
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

require_once "./vendor/autoload.php";

// Retrieve session data
$username = $_SESSION['username'];

// Check if order_id is set
if (!isset($_POST['order_id'])) {
    // Redirect back to the previous page or show an error message
    header("Location: order_success.php");
    exit;
}

// Retrieve order ID from the POST data
$order_id = $_POST['order_id'];

// MongoDB connection
$mongoClient = new MongoDB\Client("mongodb://localhost:27017");

// Select database
$database = $mongoClient->wilgipro;

// Select collection
$collection = $database->tbl_order;

// Find the order by ID
$order = $collection->findOne(['_id' => new MongoDB\BSON\ObjectId($order_id)]);

// Check if the order exists
if (!$order) {
    // Redirect back to the previous page or show an error message
    header("Location: order_success.php");
    exit;
}

// Retrieve order details
$pickup_location = $order['pickup_location'];
$delivery_address = $order['delivery_address'];
$package_size = $order['package_size'];
$package_weight = $order['package_weight'];
$delivery_speed = $order['delivery_speed'];

if (isset($_POST['submit'])) {
    // Handle form submission here
    // Update the order in the database
    // Redirect to order_success.php after updating
    // Example code for updating the order:
    $updateResult = $collection->updateOne(
        ['_id' => new MongoDB\BSON\ObjectId($order_id)],
        ['$set' => [
            'pickup_location' => $_POST['pickup_location'],
            'delivery_address' => $_POST['delivery_address'],
            'package_size' => $_POST['package_size'],
            'package_weight' => $_POST['package_weight'],
            'delivery_speed' => $_POST['delivery_speed']
        ]]
    );

    if ($updateResult->getModifiedCount() > 0) {
        header("Location: order_success.php");
        exit;
    } else {
        // Handle update failure
        header("Location: order_success.php?error=update_failed");
        exit;
    }
    
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Order - Courier Management System</title>
    <style>
        /* Reset CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f4f4f4;
            color: #333;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 15px 20px;
            /* Adjusted padding for better spacing */
            display: flex;
            /* Use flexbox for layout */
            justify-content: space-between;
            /* Align items with space between */
            align-items: center;
            /* Vertically center items */
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        header h2 {
            margin: 0;
            font-size: 24px;
        }

        nav {
            display: flex;
            /* Use flexbox for layout */
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 3px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #555;
        }


        .container {
            max-width: 800px;
            /* Adjusted width for better readability */
            margin: 100px auto;
            /* Adjusted margin for better alignment */
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 28px;
            margin-bottom: 20px;
            text-align: center;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 12px 20px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
            width: 100%;
            /* Set button width to 100% */
            box-sizing: border-box;
            /* Ensure padding and border are included in width calculation */
        }

        input[type="submit"]:hover {
            background-color: #555;
        }


        footer {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
            width: 100%;
            position: fixed;
            bottom: 0;
        }

        footer p {
            text-align: center;
            margin: 0;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 12px 20px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
            width: 100%;
            /* Set button width to 100% */
            box-sizing: border-box;
            /* Ensure padding and border are included in width calculation */
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        footer {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
            width: 100%;
            position: fixed;
            bottom: 0;
        }

        footer p {
            text-align: center;
            margin: 0;
        }
    </style>
</head>

<body>
    <header>
        <h2>Courier Management System</h2>
        <nav>
            <a href="home.php">Home</a>
            <a href="placeorder.php">Place Order</a>
            <a href="order_success.php">View Order</a>
            <a href="parcel_tracking.php">Parcel Tracking</a>
            <a href="logout.php">Log Out</a>
        </nav>
    </header>

    <div class="container">
        <h1>Update Order</h1>
        <!-- Your update order form goes here -->
        <form action="#" method="post">
            <input type="hidden" name="order_id" value="<?= $order_id ?>">
            <label for="pickup_location">Pickup Location:</label>
            <input type="text" id="pickup_location" name="pickup_location" value="<?= $pickup_location ?>" required>

            <label for="delivery_address">Delivery Address:</label>
            <input type="text" id="delivery_address" name="delivery_address" value="<?= $delivery_address ?>" required>

            <label for="package_size">Package Size:</label>
            <select id="package_size" name="package_size">
                <option value="small" <?= ($package_size === 'small') ? 'selected' : '' ?>>Small</option>
                <option value="medium" <?= ($package_size === 'medium') ? 'selected' : '' ?>>Medium</option>
                <option value="large" <?= ($package_size === 'large') ? 'selected' : '' ?>>Large</option>
            </select>

            <label for="package_weight">Package Weight:</label>
            <input type="text" id="package_weight" name="package_weight" value="<?= $package_weight ?>" required>

            <label for="delivery_speed">Delivery Speed:</label>
            <select id="delivery_speed" name="delivery_speed">
                <option value="standard" <?= ($delivery_speed === 'standard') ? 'selected' : '' ?>>Standard</option>
                <option value="express" <?= ($delivery_speed === 'express') ? 'selected' : '' ?>>Express</option>
            </select>

            <input type="submit" name="submit" value="Update Order">
        </form>
    </div>

    <footer>
        <p>&copy; 2024 Courier Management System. All rights reserved.</p>
    </footer>
</body>

</html>
