<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Courier - Admin</title>
    <style>
        /* Resetting default styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body, html {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            font-size: 16px;
            background: #f4f4f4;
            color: #333;
            height: 100%;
        }

        /* Header styles */
        header {
            background: #005a87;
            color: #fff;
            padding-top: 20px;
            min-height: 70px;
            border-bottom: #0779e4 3px solid;
        }

        header a {
            color: #fff;
            text-decoration: none;
            text-transform: uppercase;
            margin: 0 15px;
        }

        .logo {
            float: left;
            margin: 0;
        }

        .logo h1 {
            margin: 0;
            padding: 0;
            font-size: 28px;
        }

        .navigation {
            float: right;
            margin-right: 30px;
        }

        .navigation ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .navigation ul li {
            display: inline;
            margin-left: 20px;
        }

        /* Button styles */
        .btn {
            display: inline-block;
            background: #0779e4;
            color: #fff;
            padding: 12px 24px;
            border: none;
            cursor: pointer;
            margin-top: 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background 0.3s;
            width: 100%; /* Set button width to 100% */
        }

        .btn:hover {
            background: #0056b3;
        }

        /* Footer styles */
        footer {
            background: #005a87;
            color: #fff;
            text-align: center;
            padding: 20px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        /* Form container styles */
        .admin-section {
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100% - 160px);
        }

        .admin-container {
            width: 80%;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .admin-container h2 {
            margin-bottom: 20px;
            text-align: center;
            color: #005a87;
        }

        /* Form styles */
        form {
            max-width: 400px;
            margin: 0 auto;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"],
        input[type="number"],
        select,
        input[type="submit"] { /* Apply width style to submit button */
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }

        select {
            appearance: none; /* Remove default arrow */
            -webkit-appearance: none; /* Remove default arrow for Safari */
            background-image: url('data:image/svg+xml;utf8,<svg fill="#000000" width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5H7z"/></svg>'); /* Add custom arrow */
            background-repeat: no-repeat;
            background-position-x: 98%;
            background-position-y: 50%;
        }

        input[type="submit"] {
            background: #0779e4;
            color: #fff;
            border: none;
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }

        input[type="submit"]:hover {
            background: #0056b3;
        }
    </style>
 
</head>
<body>
<header>
        <div class="logo">
            <h1>Courier Management System</h1>
        </div>
        <div class="navigation">
            <ul>
                <li><a href="adminindex.php">Home</a></li>
                <li><a href="track.php">Track</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </div>
    </header>
    <main><br>
        <section class="admin-section">
            <div class="admin-container">
                <h2>Update Courier</h2>
                <div class="admin-content">
                    <!-- Add a form for updating couriers -->
                    <div class="admin-box">
                       
                        <form action="#" method="POST">
                            <label for="courier-name">Courier Name:</label>
                            <input type="text" id="courier-name" name="courier-name">
                            
                            <label for="courier-type">Courier Type:</label>
                            <select id="courier-type" name="courier-type">
                                <option value="standard">Standard</option>
                                <option value="express">Express</option>
                                <!-- Add more options as needed -->
                            </select>
                            
                            <label for="courier-weight">Courier Weight (kg):</label>
                            <input type="number" id="courier-weight" name="courier-weight" step="0.1">
                            
                            <label for="courier-destination">Destination:</label>
                            <input type="text" id="courier-destination" name="courier-destination">
                            
                            <input type="submit" value="Update">
                        </form>
                    </div>
                    <!-- Delete Courier -->
                    <!-- Your other sections here -->
                </div>
            </div>
        </section>
    </main>    <footer>
        <p>&copy; 2023 Courier Management System</p>
    </footer>

    <!-- JavaScript code for handling button clicks -->
    <script>
        // JavaScript code to handle button clicks
        document.querySelector('.view-couriers').addEventListener('click', function() {
            // Redirect to view couriers page or perform AJAX request to fetch courier data
            alert('Redirecting to view couriers page or fetching courier data...');
        });

        document.querySelector('.add-courier').addEventListener('click', function() {
            // Redirect to add courier page or display a form to add a new courier
            alert('Redirecting to add courier page or displaying add courier form...');
        });

        document.querySelector('.update-courier').addEventListener('click', function() {
            // Redirect to update courier page or display a form to update an existing courier
            alert('Redirecting to update courier page or displaying update courier form...');
        });

        document.querySelector('.delete-courier').addEventListener('click', function() {
            // Redirect to delete courier page or display a confirmation dialog to delete a courier
            alert('Redirecting to delete courier page or displaying delete confirmation dialog...');
        });
    </script>
</body>
</html>
