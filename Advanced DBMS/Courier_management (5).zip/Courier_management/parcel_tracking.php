<?php
session_start();

// Check if user is not logged in, redirect to login page
if (!isset($_SESSION['username'])) {
    header('location:./');
}

require_once "./vendor/autoload.php";

// MongoDB connection
$mongoClient = new MongoDB\Client("mongodb://localhost:27017");

// Select database
$database = $mongoClient->wilgipro;

// Select collection
$collection = $database->tbl_order;

// Initialize variables to hold order details
$pickup_location = $delivery_address = $package_size = $package_weight = $delivery_speed = "";

// Retrieve logged-in user's username
$username = $_SESSION['username'];

// Handle form submission
if (isset($_POST['track'])) {
    // Retrieve tracking number from the form
    $tracking_number = $_POST['tracking_number'];

    // Retrieve order details from the database based on the tracking number and the logged-in user's username
    $order = $collection->findOne(['tracking_number' => $tracking_number, 'username' => $username]);

    // Check if order exists
    if ($order) {
        // Assign order details to variables
        $pickup_location = $order['pickup_location'];
        $delivery_address = $order['delivery_address'];
        $package_size = $order['package_size'];
        $package_weight = $order['package_weight'];
        $delivery_speed = $order['delivery_speed'];
    } else {
        // Display error message if order does not exist or does not belong to the logged-in user
        $error_message = "Order not found. Please check the tracking number.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parcel Tracking - Courier Management System</title>
    <!-- Add SweetAlert library -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <style>
        /* Reset CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f4f4f4;
            color: #333;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        header h2 {
            margin: 0;
            font-size: 24px;
        }

        nav {
            display: flex;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 3px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #555;
        }

        .container {
            max-width: 800px;
            margin: 150px auto 50px;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 28px;
            margin-bottom: 20px;
            text-align: center;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        input[type="text"] {
            width: calc(100% - 24px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            display: inline-block;
        }

        input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 12px 20px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
            width: calc(100% - 24px);
            box-sizing: border-box;
            display: inline-block;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        .order-details {
            margin-top: 30px;
        }

        .order-details p {
            margin-bottom: 10px;
        }

        footer {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
            width: 100%;
            position: fixed;
            bottom: 0;
        }

        footer p {
            text-align: center;
            margin: 0;
        }
    </style>
</head>

<body>
    <header>
        <h2>Courier Management System</h2>
        <nav>
            <a href="home.php">Home</a>
            <a href="placeorder.php">Place Order</a>
            <a href="order_success.php">View Order</a>
            <a href="parcel_tracking.php">Parcel Tracking</a>
            <a href="logout.php">Log Out</a>
        </nav>
    </header>

    <div class="container">
        <h1>Parcel Tracking</h1>
        <!-- Parcel tracking form -->
        <form action="#" method="post">
            <label for="tracking_number">Enter Tracking Number:</label>
            <input type="text" id="tracking_number" name="tracking_number" required>
            <input type="submit" name="track" value="Track Parcel">
        </form>

        <script>
    <?php if (isset($pickup_location) && !empty($pickup_location)) : ?>
        // Display order details as SweetAlert
        Swal.fire({
            title: 'Order Details for Tracking Number: <?php echo $tracking_number; ?>',
            html: `
                <p><strong>Pickup Location:</strong> <?php echo $pickup_location; ?></p>
                <p><strong>Delivery Address:</strong> <?php echo $delivery_address; ?></p>
                <p><strong>Package Size:</strong> <?php echo $package_size; ?></p>
                <p><strong>Package Weight:</strong> <?php echo $package_weight; ?></p>
                <p><strong>Delivery Speed:</strong> <?php echo $delivery_speed; ?></p>
            `,
            icon: 'success'
        });
    <?php elseif (isset($error_message)) : ?>
        // Display error message as SweetAlert
        Swal.fire({
            title: 'Error',
            text: '<?php echo $error_message; ?>',
            icon: 'error'
        });
    <?php endif; ?>
</script>

    </div>

    <footer>
        <p>&copy; 2024 Courier Management System. All rights reserved.</p>
    </footer>
</body>

</html>
