<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('location:./');
}
require_once "./vendor/autoload.php";

// MongoDB connection
$mongoClient = new MongoDB\Client("mongodb://localhost:27017");

// Select database
$database = $mongoClient->wilgipro;

// Check if orderId is set in the POST request
if (isset($_POST['orderId'])) {
    // Select collection
    $collection = $database->tbl_order;

    // Get the orderId from the POST data
    $orderId = $_POST['orderId'];

    try {
        // Update the order status to 'Dispatched'
        $result = $collection->updateOne(
            ['_id' => new MongoDB\BSON\ObjectID($orderId)],
            ['$set' => ['orderstatus' => 'Dispatched']] // Change order status to 'Dispatched'
        );

        // Check if the update was successful
        if ($result->getModifiedCount() > 0) {
            // Send a success response
            echo json_encode(['success' => true]);
        } else {
            // If no documents were modified, send an error response
            echo json_encode(['success' => false, 'message' => 'Order not found or already dispatched']);
        }
    } catch (Exception $e) {
        // Send an error response
        echo json_encode(['success' => false, 'message' => 'Error dispatching order: ' . $e->getMessage()]);
    }
} else {
    // Send an error response if orderId is not set
    echo json_encode(['success' => false, 'message' => 'Order ID not provided']);
}
?>
