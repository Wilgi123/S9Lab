<?php
session_start();

if (isset($_POST['submit'])) {
    require_once "./vendor/autoload.php";
   
    $username = $_POST['username'];
    $password = $_POST['password'];

    // MongoDB connection
    $con = new MongoDB\Client("mongodb://localhost:27017");
    $db = $con->wilgipro;
    $collection = $db->tbl_reg; 

    // Query MongoDB to find the user
    $user = $collection->findOne(['username' => $username]);

    if ($user && password_verify($password, $user['password'])) {
        // Check if user status is active
        if ($user['status'] === 'Active') {
            // Authentication successful, set session variable and redirect to home page
            $_SESSION['username'] = $username;
            
            // Check if session already exists
            $sessionCollection = $db->sessions;
            $existingSession = $sessionCollection->findOne(['_id' => session_id()]);
            
            if (!$existingSession) {
                // Create session document in MongoDB
                $sessionCollection->insertOne(['_id' => session_id(), 'username' => $username]);
            }
            
            header("Location: home.php");
            exit;
        } else {
            // User status is inactive, display error message
            $error_message = "Your account is inactive. Please contact the administrator.";
        }
    } else {
        // Check if the login attempt is from the admin
        $adminCollection = $db->tbl_admin;
        $admin = $adminCollection->findOne(['username' => $username]);

        if ($admin && password_verify($password, $admin['password'])) {
            // Admin login successful, set session variable and redirect to admin page
            $_SESSION['admin'] = $username;
            header("Location:adminindex.php");
            exit;
        } else {
            // Authentication failed, display error message
            $error_message = "Invalid username or password";
        }
    }
}
?>





<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Login</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        padding-top: 80px; /* Add padding to create space for the header */
    }
    .container {
        max-width: 400px;
        margin: 80px auto;
        padding: 40px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    h2 {
        text-align: center;
    }
    input[type="text"],
    input[type="password"],
    input[type="submit"] {
        width: 100%;
        padding: 10px;
        margin-top: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    input[type="submit"] {
        background-color: #4caf50;
        color: white;
        border: none;
        cursor: pointer;
    }
    input[type="submit"]:hover {
        background-color: #45a049;
    }
    .error {
        color: red;
        text-align: center;
    }
    .signup-link {
            text-align: center;
            margin-top: 20px;
        }
</style>
</head>
<body>
<?php include 'header.php'; ?> <!-- Include header -->
    <div class="container">

        <h2>User Login</h2>
        <?php if (isset($error_message)) { ?>
            <p class="error"><?php echo $error_message; ?></p>
        <?php } ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <input type="submit" name="submit" value="Login">
            </div>
            <div class="signup-link">
            <p>Don't have an account? <a href="signup.php">Sign up</a></p>
        </div>
        </form>
    </div>
    <?php include 'footer.php'; ?> <!-- Include footer -->
</body>
</html>
