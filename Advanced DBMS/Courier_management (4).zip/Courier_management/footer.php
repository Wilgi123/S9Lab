<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
    <style>
        /* footer.php */
        footer {
            background-color: #222; /* Darker background color */
            color: #fff;
            padding: 10px 0; /* Reduce padding for a sleeker look */
            text-align: center;
            width: 100%; /* Full width */
            position: fixed; /* Fix footer position */
            bottom: 0; /* Stick to the bottom */
            z-index: 1000; /* Ensure footer is above other content */
            box-shadow: 0 -2px 4px rgba(0, 0, 0, 0.1); /* Add shadow for depth */
        }

        footer p {
            margin: 0; /* Remove default margin for cleaner appearance */
            font-size: 14px; /* Reduce font size for better proportion */
        }
    </style>
</head>
<body>
    <!-- footer.php -->
    <footer>
        <p>&copy; 2024 Courier Management System. All rights reserved.</p>
    </footer>
</body>
</html>
