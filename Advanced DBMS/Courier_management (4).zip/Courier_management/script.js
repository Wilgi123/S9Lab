// This script.js file will contain JavaScript code that can be used across different pages of the Courier Management System.

document.addEventListener('DOMContentLoaded', function() {
    // This function will run once the DOM is fully loaded.

    // Example of functionality: Toggle navigation for mobile view
    const navToggle = document.querySelector('.nav-toggle');
    const navigation = document.querySelector('.navigation');

    if (navToggle) {
        navToggle.addEventListener('click', () => {
            navigation.classList.toggle('active');
        });
    }

    // Functionality for tracking form submission
    const trackForm = document.querySelector('form[action="track.php"]');
    if (trackForm) {
        trackForm.addEventListener('submit', function(e) {
            e.preventDefault(); // Prevent the default form submission
            const trackingNumber = document.getElementById('trackingNumber').value;
            // Here you would typically make an AJAX request to your server-side script (track.php) to get tracking information.
            // For demonstration, we'll just log the tracking number to the console.
            console.log('Tracking Number:', trackingNumber);
            // You would then update the DOM with the tracking information received from the server.
        });
    }

    // Example of loading dashboard data
    const dashboardContainer = document.querySelector('.dashboard-container');
    if (dashboardContainer) {
        // Simulate fetching dashboard data from the server
        setTimeout(() => {
            document.getElementById('totalCouriers').textContent = '150';
            document.getElementById('pendingDeliveries').textContent = '45';
            document.getElementById('delivered').textContent = '105';
        }, 1000); // Simulated delay
    }

    // Add more page-specific JavaScript as needed
});
