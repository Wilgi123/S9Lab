<?php
session_start();

// Check if user is not logged in
if (!isset($_SESSION['admin'])) {
    http_response_code(403);
    exit('Unauthorized');
}

require_once "./vendor/autoload.php";

// Retrieve session data
$username = $_SESSION['username'];

// MongoDB connection
$mongoClient = new MongoDB\Client("mongodb://localhost:27017");

// Select database
$database = $mongoClient->wilgipro;

// Select collection
$collection = $database->tbl_order;

// Retrieve order ID from the AJAX request
$order_id = $_POST['order_id'];

// Update order status (example: from Dispatched to Delivered)
$updateResult = $collection->updateOne(
    ['_id' => new MongoDB\BSON\ObjectID($order_id)],
    ['$set' => ['orderstatus' => 'Delivered']]
);

if ($updateResult->getModifiedCount() > 0) {
    // Return the updated order status
    echo 'Delivered';
} else {
    // Return an error message if the order status update failed
    http_response_code(500);
    exit('Failed to update order status');
}
?>
