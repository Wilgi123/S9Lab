<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('location:./');
}

require_once "./vendor/autoload.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["orderId"])) {
    try {
        // MongoDB connection
        $mongoClient = new MongoDB\Client("mongodb://localhost:27017");

        // Select database
        $database = $mongoClient->wilgipro;

        // Select collection
        $collectionOrder = $database->tbl_order;

        // Get order ID from the POST data
        $orderId = $_POST["orderId"];

        // Delete the order from the collection
        $result = $collectionOrder->deleteOne(['_id' => new MongoDB\BSON\ObjectID($orderId)]);

        if ($result->getDeletedCount() > 0) {
            // Order successfully deleted
            header("Location: viewcourier.php"); // Redirect to the user's order page
            exit;
        } else {
            // No order found with the given ID
            echo "Order not found.";
        }
    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
    }
} else {
    // Redirect to a error page or handle the error accordingly
    echo "Invalid request.";
}
?>
