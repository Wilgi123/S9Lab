<?php
require_once "./vendor/autoload.php";

// Connect to MongoDB
$mongoClient = new MongoDB\Client("mongodb://localhost:27017");

// Select database
$database = $mongoClient->wilgipro;

// Select collections
$collectionReg = $database->tbl_reg;
$collectionOrder = $database->tbl_order;

// Fetch all users
$users = $collectionReg->find();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Couriers - Admin</title>
    <style>
        /* Resetting default styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body, html {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            font-size: 16px;
            background: #f4f4f4;
            color: #333;
            height: 100%;
        }

        header {
            background: #005a87;
            color: #fff;
            padding-top: 20px;
            min-height: 70px;
            border-bottom: #0779e4 3px solid;
        }

        header a {
            color: #fff;
            text-decoration: none;
            text-transform: uppercase;
            margin: 0 15px;
        }

        .logo {
            float: left;
            margin: 0;
        }

        .logo h1 {
            margin: 0;
            padding: 0;
            font-size: 28px;
        }

        .navigation {
            float: right;
            margin-right: 30px;
        }

        .navigation ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .navigation ul li {
            display: inline;
            margin-left: 20px;
        }

        .btn {
            display: inline-block;
            background: #0779e4;
            color: #fff;
            padding: 12px 24px;
            border: none;
            cursor: pointer;
            margin-top: 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background 0.3s;
        }

        .btn:hover {
            background: #0056b3;
        }

        footer {
            background: #005a87;
            color: #fff;
            text-align: center;
            padding: 20px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .admin-section {
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100% - 160px);
        }

        .admin-container {
            width: 80%;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .admin-container h2 {
            margin-bottom: 20px;
            text-align: center;
            color: #005a87;
        }

        .admin-content {
            display: flex;
            justify-content: space-around;
        }

        .admin-box {
            flex: 1;
            margin: 0 10px;
            text-align: center;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .admin-box:hover {
            transform: translateY(-5px);
        }

        .admin-box h3 {
            margin-bottom: 10px;
            color: #005a87;
        }

        .admin-box p {
            margin-bottom: 20px;
            color: #666;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <h1>Courier Management System</h1>
        </div>
        <div class="navigation">
            <ul>
                <li><a href="adminindex.php">Home</a></li>
                <li><a href="track.php">Track</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </div>
    </header>
    <main><br><br><br>
        <section class="admin-section">
            <div class="admin-container">
                <h2>Manage Couriers</h2>
                <div class="admin-content">
                    <!-- View Couriers -->
                    <div class="admin-box">
                        <h3>View Couriers</h3>
                        <p>View a list of all courier records.</p><br>
                        <a href="viewcourier.php" class="btn view-couriers">View</a>
                    </div>
                    <!-- Add Courier -->
                    
                </div>
            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2023 Courier Management System</p>
    </footer>

    <!-- JavaScript code for handling button clicks -->
    <script>
        // JavaScript code to handle button clicks
        document.querySelector('.view-couriers').addEventListener('click', function() {
            // Redirect to view couriers page or perform AJAX request to fetch courier data
            alert('Redirecting to view couriers page or fetching courier data...');
        });

        document.querySelector('.add-courier').addEventListener('click', function() {
            // Redirect to add courier page or display a form to add a new courier
            alert('Redirecting to add courier page or displaying add courier form...');
        });

        document.querySelector('.update-courier').addEventListener('click', function() {
            // Redirect to update courier page or display a form to update an existing courier
            alert('Redirecting to update courier page or displaying update courier form...');
        });

        document.querySelector('.delete-courier').addEventListener('click', function() {
            // Redirect to delete courier page or display a confirmation dialog to delete a courier
            alert('Redirecting to delete courier page or displaying delete confirmation dialog...');
        });
    </script>
</body>
</html>
