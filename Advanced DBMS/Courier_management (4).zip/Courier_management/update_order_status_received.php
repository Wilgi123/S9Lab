<?php
session_start();
if (!isset($_SESSION['username'])) {
    // Return JSON response with error message if user is not logged in
    echo json_encode(['success' => false, 'message' => 'User is not logged in.']);
    exit;
}

require_once "./vendor/autoload.php";

// Check if orderId is set in POST request
if (isset($_POST['orderId'])) {
    // Retrieve orderId from POST request
    $orderId = $_POST['orderId'];

    // MongoDB connection
    $mongoClient = new MongoDB\Client("mongodb://localhost:27017");

    // Select database
    $database = $mongoClient->wilgipro;

    // Select collection
    $collection = $database->tbl_order;

    try {
        // Update order status to "Received"
        $updateResult = $collection->updateOne(
            ['_id' => new MongoDB\BSON\ObjectID($orderId)],
            ['$set' => ['orderstatus' => 'Received']]
        );

        // Check if update was successful
        if ($updateResult->getModifiedCount() > 0) {
            // Return JSON response indicating success
            echo json_encode(['success' => true]);
            exit;
        } else {
            // Return JSON response with error message
            echo json_encode(['success' => false, 'message' => 'Failed to update order status.']);
            exit;
        }
    } catch (Exception $e) {
        // Return JSON response with error message
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
} else {
    // Return JSON response with error message if orderId is not set
    echo json_encode(['success' => false, 'message' => 'orderId not provided.']);
    exit;
}
?>
