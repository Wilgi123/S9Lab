<?php
session_start();

// Check if user is not logged in, redirect to login page
if (!isset($_SESSION['username'])) {
    header('location:./');
}

require_once "./vendor/autoload.php";

// Retrieve session data
$username = $_SESSION['username'];

// MongoDB connection
$mongoClient = new MongoDB\Client("mongodb://localhost:27017");

// Select database
$database = $mongoClient->wilgipro;

// Select collection
$collection = $database->tbl_order;

// Retrieve orders for the current user
$orders = $collection->find(['username' => $username]);

// Handle receiving courier
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['received_order_id'])) {
        $receivedOrderId = $_POST['received_order_id'];
        // Update the order status to received
        $updateResult = $collection->updateOne(
            ['_id' => new MongoDB\BSON\ObjectID($receivedOrderId)],
            ['$set' => ['orderstatus' => 'Received']]
        );
        if ($updateResult->getModifiedCount() > 0) {
            // Redirect to the same page after updating order status
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Success - Courier Management System</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            line-height: 1.6;
            padding-top: 70px;
            /* Adjusted padding for header */
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            display: flex;
            /* Use flexbox for layout */
            justify-content: space-between;
            /* Align items with space between */
            align-items: center;
            /* Vertically center items */
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        header h2 {
            font-size: 24px;
            margin: 0;
        }

        nav {
            display: flex;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 3px;
            transition: background-color 0.3s ease;
            margin-left: 10px;
        }

        nav a:hover {
            background-color: #555;
        }

        .container {
            max-width: 1200px;
            margin: 20px auto;
            /* Adjusted margin for better alignment */
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 28px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            /* Align text to the left */
        }

        th {
            background-color: #333;
            color: #fff;
            font-weight: bold;
            /* Make table headers bold */
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
            /* Alternate row background color */
        }

        /* Button styles */
        .action-buttons form {
            display: inline;
            /* Display form elements inline */
        }

        .action-buttons button {
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 5px;
            margin-left: 5px;
            /* Adjusted margin for spacing between buttons */
        }

        .delete-btn {
            background-color: #ff3333;
            color: #fff;
        }

        .update-btn {
            background-color: #33cc33;
            color: #fff;
        }

        .receive-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 5px;
            margin-left: 5px;
            /* Adjusted margin for spacing */
            transition: background-color 0.3s ease;
        }

        .receive-btn:hover {
            background-color: #0056b3;
        }

        footer {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
            width: 100%;
            position: fixed;
            bottom: 0;
        }

        footer p {
            margin: 0;
        }
    </style>
</head>

<body>
    <header>
        <h2>Courier Management System</h2>
        <nav>
            <a href="home.php">Home</a>
            <a href="placeorder.php">Place Order</a>
            <a href="parcel_tracking.php">Parcel Tracking</a>
            <a href="logout.php">Log Out</a>
        </nav>
    </header>
    <br><br>
    <div class="container">
        <h1>Placed Orders</h1>

        <?php
        $ordersArray = iterator_to_array($orders);
        if (count($ordersArray) > 0) : ?>
            <table>
                <tr>
                    <th>Tracking Number</th>
                    <th>Pickup Location</th>
                    <th>Delivery Address</th>
                    <th>Package Size</th>
                    <th>Package Weight</th>
                    <th>Delivery Speed</th>
                    <th>Order Status</th>
                    <th colspan="3">Action</th>
                </tr>
                <?php foreach ($ordersArray as $order) : ?>
                    <tr>
                        <td><?= $order['tracking_number'] ?></td>
                        <td><?= $order['pickup_location'] ?></td>
                        <td><?= $order['delivery_address'] ?></td>
                        <td><?= $order['package_size'] ?></td>
                        <td><?= $order['package_weight'] ?></td>
                        <td><?= $order['delivery_speed'] ?></td>
                        <td><?= $order['orderstatus'] ?></td>
                        <td class="action-buttons">
                            <?php if ($order['orderstatus'] !== 'Received') : ?>
                                <form action="update_order.php" method="post">
                                    <input type="hidden" name="order_id" value="<?= $order['_id'] ?>">
                                    <button type="submit" class="update-btn">Update</button>
                                </form>
                            <?php endif; ?>
                        </td>
                        <td class="action-buttons">
                            <?php if ($order['orderstatus'] !== 'Received') : ?>
                                <form action="delete_order.php" method="post">
                                    <input type="hidden" name="order_id" value="<?= $order['_id'] ?>">
                                    <button type="submit" class="delete-btn">Delete</button>
                                </form>
                            <?php endif; ?>
                        </td>
                        <td class="action-buttons">
                            <?php if ($order['orderstatus'] === 'Dispatched') : ?>
                                <form action="" method="post">
                                    <input type="hidden" name="received_order_id" value="<?= $order['_id'] ?>">
                                    <button type="submit" class="receive-btn">Received</button>
                                </form>
                            <?php endif; ?>
                            <!---<form action="delete_order.php" method="post">
                                <input type="hidden" name="order_id" value="<?= $order['_id'] ?>">
                                <button type="submit" class="delete-btn">Delete</button>
                            </form>-->
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else : ?>
            <p>No orders placed yet.</p>
        <?php endif; ?>
    </div>
    <br><br><br>
    <footer>
        <p>&copy; 2024 Courier Management System. All rights reserved.</p>
    </footer>
</body>

</html>