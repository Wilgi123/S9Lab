<?php
session_start();

// Check if user is not logged in, redirect to login page
if (!isset($_SESSION['username'])) {
    header('location:./');
}

// Check if order_id is set
if (!isset($_POST['order_id'])) {
    // Redirect back to the previous page or show an error message
    header("Location: order_success.php");
    exit;
}

require_once "./vendor/autoload.php";

// Retrieve session data
$username = $_SESSION['username'];

// Retrieve order ID from the POST data
$order_id = $_POST['order_id'];

// MongoDB connection
$mongoClient = new MongoDB\Client("mongodb://localhost:27017");

// Select database
$database = $mongoClient->wilgipro;

// Select collection
$collection = $database->tbl_order;

// Delete the order
$result = $collection->deleteOne(['_id' => new MongoDB\BSON\ObjectId($order_id)]);

// Check if deletion was successful
if ($result->getDeletedCount() === 1) {
    // Order deleted successfully
    // Redirect to order success page or any other page
    header("Location: order_success.php");
    exit;
} else {
    // Failed to delete order
    // Redirect back to the previous page or show an error message
    header("Location: order_success.php?error=delete");
    exit;
}
?>
